SELECT title, description, release_year, rental_rate FROM film;
