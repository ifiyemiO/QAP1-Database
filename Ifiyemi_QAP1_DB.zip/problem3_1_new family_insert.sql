INSERT into customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES ('606','1', 'Kelly', 'Roland', 'kelly.jones@sakilacustomer.com', '606' , 'true', current_date, current_date, '1');

INSERT into customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES ('607','1', 'Richard', 'Roland', 'richard.jones@sakilacustomer.com', 606 , 'true', current_date, current_date, '1');

INSERT into customer (customer_id, store_id, first_name, last_name, email, address_id, activebool, create_date, last_update, active)
VALUES ('608','1', 'Bob', 'Roland', 'bob.jones@sakilacustomer.com', 606 , 'true', current_date, current_date, '1');

select * from customer Where last_name = 'Roland';
select * from address where address_id = '606'