SELECT store_id,
    COUNT(inventory_id) AS Inventory_Count
FROM inventory
GROUP BY store_id