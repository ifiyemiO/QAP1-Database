SELECT * FROM INVENTORY
SELECT * FROM FILM
SELECT * FROM STORE

SELECT
    film.title AS Film_Title,
    store.store_id AS Store_ID,
    COUNT(inventory.inventory_id) AS Inventory_Count
FROM film
JOIN inventory ON film.film_id = inventory.film_id
JOIN store ON inventory.store_id = store.store_id
WHERE film.title = 'Aladdin Calendar'
GROUP BY film.title, store.store_id
ORDER BY Inventory_Count;
