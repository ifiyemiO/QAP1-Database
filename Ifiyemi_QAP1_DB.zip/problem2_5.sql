SELECT customer.create_date AS Customer_join_date, customer.first_name || ' ' || customer.last_name AS Customer_Full_Name,
     film.title AS Film_rented, film.rental_duration FROM customer
JOIN rental ON customer.customer_id = rental.customer_id
JOIN inventory ON rental.inventory_id = inventory.inventory_id
JOIN film ON inventory.film_id = film.film_id;


