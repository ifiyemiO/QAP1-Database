SELECT * FROM category WHERE category.name = 'Sci-Fi';
    
