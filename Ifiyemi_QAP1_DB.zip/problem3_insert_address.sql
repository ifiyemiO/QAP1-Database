INSERT into address (address_id, address, district, city_id, postal_code, phone, last_update)
VALUES ('606', '74 March Cres', 'Goulds', '300', '123456', '7092315798', current_date )

SELECT * FROM address
WHERE address_id = '606'

INSERT into address (address_id, address, district, city_id, postal_code, phone, last_update)
VALUES ('607', '123 Main Street', 'Gander', '300', '123456', '7092315798', current_date )

SELECT * FROM address
WHERE address_id = '607'

