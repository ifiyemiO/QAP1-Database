SELECT *  FROM student

INSERT INTO student (student_id, first_name, last_name, program_id, address, start_date, end_date, phone_number, email)
VALUES ('1', 'Alex', 'Dean', '1', '123 Main Street', '2024-05-03', '2025-05-03', '7091231234' ,'alex.dean@kschool.com')

INSERT INTO student (student_id, first_name, last_name, program_id, address, start_date, end_date, phone_number, email)	
VALUES ('2', 'Nancy', 'Saunders', '1', '456 Rose Ave.', '2024-09-01', '2025-09-01', '7803672356' ,'nancy.Saunders@kschool.com')

INSERT INTO student (student_id, first_name, last_name, program_id, address, start_date, end_date, phone_number, email)	
VALUES ('3', 'Ray', 'Baldwin', '2', '34 Brooks Road', '2025-01-02', '2026-01-02', '123456789', 'ray.baidwin@kschool.com')

INSERT INTO student (student_id, first_name, last_name, program_id, address, start_date, end_date, phone_number, email)
VALUES ('4','Terry', 'Snow', '2', '15 Jade pl.', '2025-01-15', '2026-01-15', '7091231234', 'terry.snow@kschool.com')