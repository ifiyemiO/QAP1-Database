UPDATE customer
SET address_id = '607'
	WHERE last_name = 'Roland';

SELECT * FROM customer where last_name = 'Roland';