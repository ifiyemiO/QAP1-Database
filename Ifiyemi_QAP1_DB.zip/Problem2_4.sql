SELECT store_id, first_name ||' '|| last_name AS Employee, email FROM staff
ORDER BY staff_id ASC