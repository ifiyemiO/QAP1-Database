DELETE FROM address
WHERE address_id = '606'

SELECT * FROM address 
WHERE address_id = '606'

SELECT * FROM address 
WHERE address_id = '607'

