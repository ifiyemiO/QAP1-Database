INSERT INTO program (program_name, program_overview, duration) VALUES
('Software Development', 'Technology-based solutions to grow industry operations', '64 weeks'),
('Pharmacy Technician', 'Gain knowledge relevant to technical and clerical aspect of pharmacy profession', '74 weeks'),
('Digital Health Administration', 'Core office administartion skills, essential technological skills for digital workforce', '16 months'),
('Dental Assisting', 'provides comprehensive training in practice management, direct patient care and steralization', '36 weeks');

SELECT * FROM program;

